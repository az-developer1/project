<?php 
 session_start();
 include 'connection.php';
 include 'encryption.php';
  
 $username = $_POST['username'];
 $pass     = $_POST['pass'];
 $confirm  = $_POST['confirm'];
 $fName    = $_POST['fName'];
 $lName    = $_POST['lName'];
 $gender   = $_POST['gender'];
 $phone    = $_POST['phone'];
 $email    = $_POST['email'];
 $address  = $_POST['address'];
 $country  = $_POST['country'];

 $_SESSION['username'] = $username;
 $_SESSION['pass']     = $pass;
 $_SESSION['confirm']  = $confirm;
 $_SESSION['fName']    = $fName ;
 $_SESSION['lName']    = $lName;
 $_SESSION['gender']   = $gender;
 $_SESSION['phone']    = $phone;
 $_SESSION['email']    = $email;
 $_SESSION['address']  = $address;
 $_SESSION['country']  = $country; 

 
 if(empty($username))
   $_SESSION['msg'] = 'Enter username';
 else {
    $sqlUser = "Select * From clients Where Username = '$username'";  
    $rsUser  = mysqli_query($con, $sqlUser);

    $num_rows= mysqli_num_rows($rsUser);
 
    if ($num_rows >0)
     $_SESSION['msg'] = 'Not available';
    else
     if(empty($pass))
      $_SESSION['msg'] = 'Enter password';
     else
      if(strlen($pass) < 6)
       $_SESSION['msg'] = 'Minimum length of password is 6 characters';
      else
       if(chkPass($pass) == false)
        $_SESSION['msg'] = 'Password must include small, capital letter, digit and symbol, space not allowed';
       else
        if($pass != $confirm)
         $_SESSION['msg'] = 'Password is not confirmed';
        else
         if(empty($fName))
          $_SESSION['msg'] = 'Enter first name';
         else
          if(empty($lName))
           $_SESSION['msg'] = 'Enter last name';
          else
           if(empty($phone))
            $_SESSION['msg'] = 'Enter phone';
           else
            if(empty($email))
             $_SESSION['email'] = 'Ente email';
            else
             if(empty($address))
              $_SESSION['msg']  = 'Enter address';
             else
              if($country==0)
               $_SESSION['msg'] = 'Select a country';
              else {
               $pass = Encrypt($pass);
               $sqlClient = "INSERT INTO clients(FName, LName, GenderID, Phone, Email, Address, CountryID, Username, Password) Values('$fName', '$lName', '$gender', '$phone', '$email','$address', '$country', '$username', '$pass')";

               if(mysqli_query($con, $sqlClient)) {
                 $_SESSION['msg'] = 'Record has been saved successfully';
                 $_SESSION['saved'] = true;
               }
               else
                 $_SESSION['msg'] = 'Cannot Save Product';
              }
    }
 header('location:reg.php');

?>