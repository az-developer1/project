<?php
  session_start();
  include 'connection.php';

	if(isset($_SESSION['client']))
	{
		$mID = $_GET['movieID'];
		$clientID = $_SESSION['client'];
		$saleDate = date('y/m/d');

  $sqlChkSale = "Select * From sales Where ClientID = $clientID And Opened = 1";
  $rsSale = mysqli_query($con, $sqlChkSale);

  $num_rows= mysqli_num_rows($rsSale);
     
  if ($num_rows > 0){      
     $rSale = mysqli_fetch_assoc($rsSale);

     $sqlSaleDetail="Select * From saledetail Where SaleID=" . (int) $rSale['SaleID'] . " And MovieID= " . (int) $mID;
     
     $rsSaleDetail = mysqli_query($con, $sqlSaleDetail);
     
     $num_rows= mysqli_num_rows($rsSaleDetail);
     
     if ($num_rows > 0){      
       //Add 1 to the Qty
       $rSaleDetail = "UPDATE saledetail SET Qty=Qty+1 WHERE SaleID = " . (int) $rSale['SaleID'] . " And MovieID = " . (int) $mID;

       $run_qty = mysqli_query($con, $rSaleDetail);
     }
     else {
      //Insert new movie in the same Sale
      $s = $rSale['SaleID'];

      $rSaleDetail = "INSERT INTO saleDetail(SaleID, MovieID, Qty) Values('$s', '$mID', 1)";

      $run_SaleDetail = mysqli_query($con, $rSaleDetail);  
     }
  }
  else {
   //Create new Sale
   $sqlSales = "INSERT INTO sales(ClientID, saleDate, Opened) Values('$clientID', CURDATE(), 1)";

   if(mysqli_query($con, $sqlSales)) {
    // echo 'Inserted Successfully<br/>';
    $rsSale = mysqli_query($con, 'SELECT * FROM sales ORDER BY saleID DESC LIMIT 1');
    $r      = mysqli_fetch_assoc($rsSale);

    $SaleID = $r['SaleID'];
    $sqlSaleDetail = "INSERT INTO saleDetail(SaleID, MovieID, Qty) Values('$SaleID', '$mID', 1)";

         if(mysqli_query($con, $sqlSaleDetail))
            echo '<br/>Record inserted in saleDetail successfully';
         else
            echo '<br/>Cannot insert into saleDetail';
      }
    /* else
         echo '<br/>Cannot insert record';*/
    }

    if(isset($_SESSION['return'])){
       if($_SESSION['return'] == 'Basket'){
          header('location:basketDetail.php');
          exit();
       }
    }
    header('location:home.php');
    exit();
  }    

 else{
		header('location:login.php');
	}
?>