<!doctype html>

<html>
<head>
<title>Home page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="bootstrap/bootstrap.min.css" rel="stylesheet" />
<script src="bootstrap/bootstrap.bundle.min.js"></script>

<link href="styles/style.css" rel="stylesheet" />

<style>
 #logo{
   background-image: url(assets/logo.jpg);
   background-repeat: no-repeat; 
   background-size: cover;   
   border: 2px solid black;
   border-radius: 20%;
   height: 100px;
   width: 140px;
 }

 #card{
  background-color: white;
  border-radius: 50%;
  width: 60px;
  height: 60px;
 }

 #logout a{
  color: white;
 }

 #logout a:hover{
  text-decoration: underline;
 }
</style>
<?php 
    include 'connection.php';

    session_start();
    if(isset($_SESSION['client'])){
      $client  = $_SESSION['client'];
      $_SESSION['return'] = 'Home';
    }
    else{
      header('location:login.php');
    }

    //Check if there is opened basket and if there are movies in it
    $sqlBasket = "Select * From Sales, SaleDetail Where Sales.SaleID = SaleDetail.SaleID And Opened=1 And ClientID = " . $client;
    
    $rsBasket = mysqli_query($con, $sqlBasket);
    
    $num_rows= mysqli_num_rows($rsBasket);


    //Display all categories as hyperlinks
    $sqlCat = "Select * From categories Order By CategoryName";
    $rsCat  = mysqli_query($con, $sqlCat);

    if(isset($_GET['catID'])){
    	$catID = $_GET['catID'];
		  if($catID==0)
			    $sqlMovies = 'Select * From movies';
		  else
			   $sqlMovies = 'Select * From movies, movieCategories Where movies.MovieID = movieCategories.MovieID And movieCategories.CategoryID = ' . $catID;
    }
    else
    	$sqlMovies = 'Select * From movies';

    $rsMovies = mysqli_query($con, $sqlMovies);
 ?>  
   
</head>

<body>
<div class="container-fluid 
            p-3
            bg-danger 
            text-white">

  <div class="row">
    <div class="col-md-3">
      <div id="logo"></div>
    </div>

    <div class="col-md-7">
    </div>

    <div class="col-md-1">
     <div id="card">
     <?php if ($num_rows > 0){  ?>
       <a href="basketDetail.php"><img src="assets/basket.png" /></a>
     <?php 
      }
      else { ?>
       <img src="assets/basket.png" />
     <?php } ?>      
     </div>
   </div>

   <div id="logout" class="col-md-1">
     <a href="logout.php">Logout</a>
   </div>

  </div>
</div>

<div class="container mt-2">

<table border="1" bordercolor="black" cellspacing="0" width="100%">
 <td width="15%" valign="top">
  <a href="home.php?mID=0">All Categories</a> <br/>
  <?php 
    while($rCat = mysqli_fetch_assoc($rsCat)){ 	
  ?>
    <A href="home.php?catID=<?php echo $rCat['CategoryID']; ?>"><?php echo $rCat['CategoryName']; ?>
    </A><br/>
  <?php
    }
  ?>
 </td>

 <td width="80%" valign="top">
   <?php
     while($rMovie = mysqli_fetch_assoc($rsMovies)){
   ?>
	  <a href="moviedetails.php?movid=<?php echo $rMovie['MovieID']; ?>">
      <img src="movies/<?php echo $rMovie['MovieID'];?>.jpg" width="200" height="300" />
	  </a>
   <?php
     }
   ?>
 </td>
</tr>
</table>

</div>
</body>
</html>