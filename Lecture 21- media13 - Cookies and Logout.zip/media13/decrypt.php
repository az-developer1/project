<?php
  include 'encryption.php';

  $P = $_GET['P'];

  echo Decrypt($P);
?>