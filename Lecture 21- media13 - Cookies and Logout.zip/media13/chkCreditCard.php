<?php
 session_start();
 include 'connection.php';

 $owner   = $_POST['owner'];
 $cvv     = $_POST['cvv'];
 $cardNbr = $_POST['cardNbr'];
 $expMonth= $_POST['expMonth'];
 $expYear = $_POST['expYear'];

 $_SESSION['owner']   = $owner;
 $_SESSION['cvv']     = $cvv;
 $_SESSION['cardNbr'] = $cardNbr;
 $_SESSION['expMonth']= $expMonth;
 $_SESSION['expYear'] = $expYear;

 if(empty($owner))
   $_SESSION['msg'] = "Enter owner name";
 else
  if(empty($cvv))
    $_SESSION['msg'] = "Enter cvv nbr";
  else
   if(empty($cardNbr))
     $_SESSION['msg'] = "Enter card nbr";
   else
    if(! is_numeric($cvv) || strlen($cvv) < 3 || strlen($cvv) > 4)
      $_SESSION['msg'] = "Invalid CVV nbr";
    else
     if(! is_numeric($cardNbr) || strlen($cardNbr) != 16)
       $_SESSION['msg'] = "Invalid card nbr";
     else{
       //Online banking detection to validate card
       //We send the card information to online banking here
       //Wait for online banking notification if no error in card just close the basket 
       //And print out the invoice report to the client then return back to home page
       //Else if there is an error with the card content return to the credit card file 
       //And show the notification error to the client

       // Close the opened basket sale 
       //Now get the Sale ID from crediCard pg to determine the Sale Transaction ID 
       
       $SID      = $_POST['SID'];

       $rSale    = "UPDATE sales SET Opened=0 Where SaleID = " . (int) $SID;

       $run_Sale = mysqli_query($con ,$rSale);

       header('location:home.php');
       exit(); 
     }

header('location:creditCard.php');

?>
