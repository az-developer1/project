<!DOCTYPE html>
<html>
<head>
  <title>Slick Playground</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="bootstrap/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="styles/slick.css">
  <link rel="stylesheet" href="styles/slick-theme.css">
  <link href="styles/style.css" rel="stylesheet" />

  <link href="styles/style2.css" rel="stylesheet" />

  <link rel="stylesheet" href="bootstrap/bootstrap.min.css" />
  <link rel="stylesheet" href="styles/font-awesome.css" />

  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.min.js"></script>

  <script src="bootstrap/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.js"></script>
  <script src="js/slick.js" charset="utf-8"></script>
  
  <script>
    $(document).on('ready', function() {
      $('.variable').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
      });
    });

    //AJAX search function
    function Get(){
      $.post('searchProcess.php', {searchMov: frmSearch.searchMov.value},

      function(output){

        if(frmSearch.searchMov.value== ''){
          $('#result').css('display', 'none');
        }
        else{
          $('#result').css('display', 'block');
          $('#result').css('overflow', 'auto');
          $('#result').html(output).fadeIn();
        }

      });
    }

  </script>    

  <style>
    html, body {
      margin: 0;
      padding: 0;
    }

    * {
      box-sizing: border-box;
    }

    .slider {
        width: 75%;
        margin: 100px auto;
    }

    .slick-slide {
      margin: 0px 20px;
    }

    .slick-slide img {
      width: 100%;
      height:  100%;
    }

    .slick-prev:before,
    .slick-next:before {
      color: black;
    }

    .slick-slide {
      transition: all ease-in-out .3s;
      opacity: .2;
    }
    
    .slick-active {
      opacity: .5;
    }

    .slick-current {
      opacity: 1;
    }

 #logo{
   background-image: url(assets/logo.jpg);
   background-repeat: no-repeat; 
   background-size: cover;   
   border: 2px solid black;
   border-radius: 20%;
   height: 100px;
   width: 140px;
 }

 .container {
    margin-top: 200px
}

.btn:hover {
    color: #fff
}

.input-text:focus {
    box-shadow: 0px 0px 0px;
    border-color: #f8c146;
    outline: 0px
}

.form-control {
    border: 1px solid #f8c146
}


#result{
  position:absolute;
  top: 48px;
  left: 0;
  width: 600px;
  height: 250px;
  background-color: rgba(255, 255, 255, 0.9);
  border: 1px solid grey;
  display: none;
  z-index: 1;
  border-radius: 0 0 10px 10px;
  padding: 4px 10px;
}

a{
  font-family: calibri;
  color: black;
  text-decoration: none;
  font-weight: bold;
  display: block;
}

a:hover {
  background-color: rgba(180, 180, 180, 0.7);
  color: white;
}

#loader{
  background-image: url('assets/spinner.gif');
  width: 64px;
  height: 64px;
  display:none;
}

 #login a{
  color: white;
 }

 #login a:hover{
  text-decoration: underline;
 }
</style>  

<?php 
 session_start();
 
 if(isset($_COOKIE['user'])){
  echo "Cookie '" . 'user' . "' is set!<br>";
  echo "Value is: " . $_COOKIE['user'];
  $_SESSION['client']= $_COOKIE['user'];
  echo "<br/>" . $_SESSION['client'];
}
 else
  echo 'No cookies';
?>  
</head>
<body>

<div class="container-fluid 
            p-3
            bg-danger 
            text-white">

  <div class="row">
    <div class="col-md-2">
      <div id="logo"></div>
    </div>

    <div class="col-md-8">

      <!-- Add search box here -->
      <form name="frmSearch" onkeydown="Get();">
        <div class="input-group mb-2">
          <input type       ="text"
                 autocomplete="off" 
                 name       ="searchMov"
                 class      ="form-control input-text"
                 placeholder="Search movies . . . " />

          <div class="input-group-append">
            <button class="btn btn-outline-warning btn-lg">
              <i class="fa fa-search"></i>
            </button>
          </div>


          <div id="result"></div>
        </div>
      </form>

    </div>

    <div class="col-md-1"></div> 

    <div id="login" class="col-md-1">
     <?php if(!isset($_SESSION['client'])){?>
       <a href="login.php">Login</a>
     <?php }?>
   </div>    
  </div>
</div>

<div class="container mt-2">
  <div id="loader"></div>
  <section class="variable slider" style="margin-top:0;">
    <div><img src="movies/1.jpg" /></div>
    <div><img src="movies/2.jpg" /></div>
    <div><img src="movies/3.jpg" /></div>
    <div><img src="movies/5.jpg" /></div>
    <div><img src="movies/6.jpg" /></div>
    <div><img src="movies/7.jpg" /></div>
    <div><img src="movies/8.jpg" /></div>
    <div><img src="movies/9.jpg" /></div>
    <div><img src="movies/10.jpg" /></div>
    <div><img src="movies/11.jpg" /></div>    
  </section>
</div>



</body>
</html>
