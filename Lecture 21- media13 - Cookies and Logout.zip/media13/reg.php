<!doctype html>
<html>
<head>
<title>Northwind</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="bootstrap/bootstrap.min.css" rel="stylesheet" />
<script src="bootstrap/bootstrap.bundle.min.js"></script>

<?php 
  session_start();

  include 'connection.php';

  $sqlCountries = 'Select CountryID, CountryName From Countries';
  $rsCountries  = mysqli_query($con, $sqlCountries);   
?>

<style>
 #header{
 	font-size: 32pt;
 	color: navy;
 }
</style>
</head>

<body>
<form name  ="frmReg"
      action="chkReg.php"
      method="post">
<table border     ="1"
       bordercolor="black"      
       cellspacing="0"
       align      ="center"
       width      ="35%">

<tr>
 <th colspan="2" id="header">Registration Form</th>
</tr>

<tr>
 <td><label for="user">Username</label></td>
 <td><input type="text" id="user" name="username"
            value="<?php if(isset($_SESSION['username'])) echo $_SESSION['username'];?>" /></td>
</tr>

<tr>
 <td><label for="pass">Password</label></td>
 <td><input type="text" id="pass" name="pass" 
            value="<?php if(isset($_SESSION['pass'])) echo $_SESSION['pass'];?>" /></td>
</tr>

<tr>
 <td><label for="confirm">Confirm</label></td>
 <td><input type="text" id="confirm" name="confirm" 
 	        value="<?php if(isset($_SESSION['confirm'])) echo $_SESSION['confirm'];?>"/></td>
</tr>

<tr>
 <td><label for="fName">First Name</label></td>
 <td><input type="text" id="fn" name="fName"
            value="<?php if(isset($_SESSION['fName'])) echo $_SESSION['fName'];?>" /></td>
</tr>

<tr>
 <td><label for="lName">Last Name</label></td>
 <td><input type="text" id="ln" name="lName" 
 	        value="<?php if(isset($_SESSION['lName'])) echo $_SESSION['lName'];?>"/></td>
</tr>

<tr>
 <td>Gender</td>
 <td>
 	<input type="radio" name="gender" value="1" checked  
         <?php if(isset($_SESSION['gender'])) if($_SESSION['gender'] == 1) echo ' checked'; ?> />Male
 	&nbsp;&nbsp;
 	<input type="radio" name="gender" value="2" 
         <?php if(isset($_SESSION['gender'])) if($_SESSION['gender'] == 2) echo ' checked'; ?> />Female
 </td>
</tr>

<tr>
 <td><label for="phone">Phone</label></td>
 <td><input type="text" id="phone" name="phone"
            value="<?php if(isset($_SESSION['phone'])) echo $_SESSION['phone'];?>"/></td>
</tr>

<tr>
 <td><label for="email">Email</label></td>
 <td><input type="email" id="email" name="email"
            value="<?php if(isset($_SESSION['phone'])) echo $_SESSION['email'];?>" /></td>
</tr>

<tr>
 <td><label for="address">Address</label></td>
 <td><input type="text" id="address" name="address" size="40" 
            value="<?php if(isset($_SESSION['address'])) echo $_SESSION['address'];?>" 	/></td>
</tr>

<tr>
 <td><label for="country">Country</label></td>
 <td>
  <select id      ="country" 
          name    ="country">
   	<option value="0" hidden>Select Country</option>

   	<?php
      while($rCountry = mysqli_fetch_assoc($rsCountries)){
    ?>
      <option value="<?php echo $rCountry['CountryID'];?>"
      	      <?php if(isset($_SESSION['country'])) 
      	              if($_SESSION['country'] == $rCountry['CountryID']) echo ' selected';?>>
      	<?php echo $rCountry['CountryName'];?>
      </option>
    <?php
      }
   	?>
   </select> 	
 </td>
</tr>

<tr>
 <td colspan="2" align="right">
   <input type="reset" value="Clear" class="btn btn-success" />
   &nbsp;&nbsp;
   <input type="submit" value="Save" class="btn btn-success" />
 </td>
</tr>

<tr>
 <td colspan="4">
 	<?php
 	 if(isset($_SESSION['msg'])) echo $_SESSION['msg'];

 	 if(isset($_SESSION['saved'])) if($_SESSION['saved']==true) {
 	?>
     <script>
     	document.frmReg.username.value = '';
     	document.frmReg.pass.value     = ''
     	document.frmReg.confirm.value  = ''
     	document.frmReg.fName.value    = '';
     	document.frmReg.lName.value    = '';
     	document.frmReg.gender.value   = 1;
     	document.frmReg.phone.value    = '';
     	document.frmReg.address.value  = '';
     	document.frmReg.country.value  = 0;
      document.frmReg.email.value    = '';
     </script>
    <?php
      }
       unset($_SESSION['msg']);
       unset($_SESSION['username']);
       unset($_SESSION['pass']);
       unset($_SESSION['confirm']);
       unset($_SESSION['fName']);
       unset($_SESSION['lName']);
       unset($_SESSION['gender']);
       unset($_SESSION['phone']);
       unset($_SESSION['email']);
       unset($_SESSION['address']);
       unset($_SESSION['country']);
 	?>
 </td>
</tr>
</table>       
</form>      
</body>
</html>