<!DOCTYPE html>
<html>
<?php  session_start(); ?>

<head>
<title>Checkout</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="styles/crediCard.css">
<link rel="stylesheet" type="text/css" href="styles/demo.css">

<style>
 #logo{
   background-image: url(assets/logo.jpg);
   background-repeat: no-repeat; 
   background-size: cover;   
   border: 2px solid black;
   border-radius: 20%;
   height: 100px;
   width: 140px;
 }
</style>
</head>

<body>
<div class="container-fluid 
            p-3
            bg-danger 
            text-white">

  <div class="row">
    <div class="col-md-12">
      <div id="logo"></div>
    </div>
  </div>
</div>

<div>
 <div class="creditCardForm" style="margin-top:25px;margin-bottom:10px;">
  <div class="heading"><h1>Confirm Purchase</h1></div>
  <div class="payment">
   <form name="frmCreditCard" method="post" action="chkCreditCard.php">
   
    <?php
      //Get the sale ID from the basketDetail to pass it to chkCreditCard 
      $SID = $_GET['SID'];
    ?>

    <input type="hidden" name="SID" value="<?php echo $SID; ?>" />

    <div class="form-group owner">
     <label for="owner">Owner</label>
     <input type ="text" 
            class="form-control" 
            id   ="owner" 
            name ="owner"
            value="<?php if(isset($_SESSION['owner'])) echo $_SESSION['owner']; ?>">
    </div>
    <div class="form-group CVV">
     <label for="cvv">CVV</label>
     <input type ="text" 
            class="form-control" 
            id   ="cvv" 
            name ="cvv"
            value="<?php if(isset($_SESSION['cvv'])) echo $_SESSION['cvv']; ?>">
    </div>
    <div class="form-group" id="card-number-field">
     <label for="cardNbr">Card Number</label>
     <input type ="text" 
            class="form-control" 
            id   ="cardNbr" 
            name ="cardNbr"
            value="<?php if(isset($_SESSION['cardNbr'])) echo $_SESSION['cardNbr']; ?>">
    </div>
    <div class="form-group" id="expiration-date">
     <label for="expMonth">Expiration Date</label>
     <select name="expMonth">
      <option value="01">January</option>
      <option value="02">February </option>
      <option value="03">March</option>
      <option value="04">April</option>
      <option value="05">May</option>
      <option value="06">June</option>
      <option value="07">July</option>
      <option value="08">August</option>
      <option value="09">September</option>
      <option value="10">October</option>
      <option value="11">November</option>
      <option value="12">December</option>
     </select>
     <select name="expYear">
      <option value="21">2021</option>
      <option value="22">2022</option>
      <option value="23">2023</option>
      <option value="24">2024</option>
      <option value="25">2025</option>
      <option value="26">2026</option>
     </select>
    </div>
    <div class="form-group" id="credit_cards">
     <img src="assets/creditCard/visa.jpg" id="visa">
     <img src="assets/creditCard/mastercard.jpg" id="mastercard">
     <img src="assets/creditCard/amex.jpg" id="amex">
    </div>
    <div class="form-group" id="pay-now">
     <button type="submit" class="btn btn-default" id="confirm-purchase">Confirm</button>
    </div>
   </form>
  </div>
 </div>
</div>

<div>
<center>
<?php 
  if(isset($_SESSION['msg']))
      echo $_SESSION['msg'];
  
  unset($_SESSION['msg']);
  unset($_SESSION['owner']);
  unset($_SESSION['cvv']);
  unset($_SESSION['cardNbr']);
?>
</center>
</div
</body>

</html>
