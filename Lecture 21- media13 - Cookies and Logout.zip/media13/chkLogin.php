<?php
 session_start();

 include 'connection.php';
 include 'encryption.php';
 
 $user = $_POST['user'];
 $pass = $_POST['pass'];

 $_SESSION['user'] = $user;
 $_SESSION['pass'] = $pass;

 if(empty($user))
   $_SESSION['msg']='Enter user name';
 else
   if(empty($pass))
     $_SESSION['msg']='Enter password';
   else{
     $sqlUser = "SELECT * FROM clients WHERE username = '" . $user . "'";
     $rsUser  = mysqli_query($con, $sqlUser);

     $num_rows= mysqli_num_rows($rsUser);
     
     if ($num_rows <= 0) 
        $_SESSION['msg'] = 'Invalid username';
     else {
      	$rUser = mysqli_fetch_assoc($rsUser); 
     	  if(Decrypt($rUser['Password']) != $pass)
     		   $_SESSION['msg']='Incorrect Password';
     	  else {
			     $_SESSION['client']= $rUser['ClientID'];

           if(isset($_POST['keep'])){
             setcookie("user", $rUser['ClientID'], time() + (86400 * 30), "/"); 
           }

           unset($_SESSION['msg']);
           unset($_SESSION['user']);
           unset($_SESSION['pass']);           
     		   header('location:home.php');
     		   die();
         }
      	}
     }

   
   header('location:login.php');
?>