<?php
 include 'connection.php';
 
 $searchMov = $_POST['searchMov'];
 
 $sqlSearch = "Select * From movies Where LOWER(Title) Like '%" . strtolower($searchMov) . "%'";
 $rsSearch  = mysqli_query($con, $sqlSearch);

 if(mysqli_num_rows($rsSearch) <= 0)
   echo 'No Movie';
 else {
  while($rSearch = mysqli_fetch_assoc($rsSearch)){ 
?>
   <a href="movieDetails.php?movid=<?php echo $rSearch['MovieID']; ?>">
      <?php echo $rSearch['Title']; ?>
   </a>
<?php 
  } 
 }
?>
