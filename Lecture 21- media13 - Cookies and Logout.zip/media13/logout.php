<?php
 session_start();
 session_destroy();
 $_SESSION = array();

 // set the expiration date to one hour ago and that will delete the cookie
 setcookie("user", "", time() - 3600, "/"); 
 header('location:index.php');
?>
