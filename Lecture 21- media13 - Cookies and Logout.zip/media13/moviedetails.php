<!doctype html>
<html>
<head>
<meta charset="utf-8">

<link href="styles/style.css" rel="stylesheet" type="text/css" />

<style>
	th {
		text-align:left;
		cellspacing:0;
	}
</style>

<?php
  include 'connection.php';
  $sqlMovie    = "Select * From movies, directors Where directors.DirectorID = movies.DirectorID And MovieID = " . $_GET['movid'];

  $sqlMovieCat = "Select CategoryName From categories, moviecategories Where categories.CategoryID = moviecategories.CategoryID And MovieID = " . $_GET['movid'];

  $sqlMovieAct = "Select ActorName From actors, movieactors Where actors.ActorID = movieactors.ActorID And MovieID = " . $_GET['movid'];


  $rsMovie = mysqli_query($con,$sqlMovie);
  $mov     = mysqli_fetch_assoc($rsMovie);

  $rsMovieCat = mysqli_query($con, $sqlMovieCat);
  $rsMovieAct = mysqli_query($con, $sqlMovieAct);
?>
</head>

<body>

<table border="1" bordercolor="black" cellspacing="0" width="65%" align="center">
	<tr>
		<td colspan="2">
			<img src="movies/<?php echo $mov['MovieID'];?>.jpg" width="200" height="300" />
		</td>
	</tr>
	<tr>
		<td width="12%">Title</td>
		<td><?php echo $mov['Title'];?></td>
	</tr>
	<tr>
		<td>Produce Year</td>
		<td><?php echo $mov['ProduceYear'];?></td>
	</tr>
	<tr>
		<td>Unit Price</td>
		<td><?php echo $mov['UnitPrice'];?></td>
	</tr>

  <tr>
  	<td>Categories</td>
  	<td>
  		<?php while($rMovieCat = mysqli_fetch_assoc($rsMovieCat)){ ?>
  			<a href="#"><?php echo $rMovieCat['CategoryName'] . ", "; ?></a>
  		<?php }?>
  	</td>
  </tr>

  <tr>
  	<td>Starring</td>
  	<td>
  		<?php while($rMovieAct = mysqli_fetch_assoc($rsMovieAct)){ ?>
  			<a href="#"><?php echo $rMovieAct['ActorName'] . ", "; ?></a>
  		<?php }?>
  	</td>
  </tr>

  <tr>
  	<td>Director</td>
  	<td><a href=""><?php echo $mov['DirectorName'];?></a></td>
  </tr>

  <tr>
  	<td valign="top">Story</td>
  	<td><?php echo $mov['Story'];?></td>
  </tr>

	<tr>
		<td colspan="2" align="center">
			<form action="addToCard.php">
				<input type="hidden" 
				       name="movieID" 
				       value="<?php echo $mov['MovieID'];?>" />
				       
				<input type ="submit" 
				       value=" Add to card " 
				       class="btn" />
			</form>
	    </td>
	</tr>
</table>

</body>

</html>