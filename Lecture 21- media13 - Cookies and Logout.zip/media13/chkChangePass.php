<?php
 session_start();
 include 'connection.php';
 include 'encryption.php';

 if(isset($_SESSION['client'])){

 	$client  = $_SESSION['client'];
 	$oldPass = $_POST['oldPass'];
 	$newPass = $_POST['newPass'];
 	$confirm = $_POST['confirm'];

    $_SESSION['oldPass'] = $oldPass;
    $_SESSION['newPass'] = $newPass;
    $_SESSION['confirm'] = $confirm;

    if(empty($oldPass))
    	$_SESSION['msg'] = "Enter old password";
    else
     if(empty($newPass))
    	$_SESSION['msg'] = "Enter new password";
     else
      if(strlen($newPass) < 6)
       $_SESSION['msg'] = 'Minimum length of password is 6 characters';
      else
       if(chkPass($newPass) == false)
        $_SESSION['msg'] = 'Password must include small, capital letter, digit and symbol, space not allowed';
       else         
    	  if($newPass != $confirm)
    		$_SESSION['msg'] = "Password not confirmed";
    	  else{
 	       $sqlClient = "Select * From Clients Where ClientID = " . $client;
 	       $rsClient  = mysqli_query($con, $sqlClient);

 	       $rClient   = mysqli_fetch_assoc($rsClient);

 	       if(Decrypt($rClient['Password']) != $oldPass)
 		      $_SESSION['msg'] = "Invalid Old Password";
 	       else {
            $newPass = Encrypt($newPass);

            $rUpdatePass = "UPDATE Clients SET Password='$newPass' WHERE ClientID = " . $client;
            $run_update  = mysqli_query($con, $rUpdatePass);
               
            unset($_SESSION['msg']);
            unset($_SESSION['oldPass']);
            unset($_SESSION['newPass']);
            unset($_SESSION['confirm']);                
            header('location:home.php');
            exit();
          }
        }
    header('location:changePass.php');
    exit();
  }
 else
 	header('location:login.php');
?>