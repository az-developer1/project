<!doctype html>
<html>
<head>
<title>Login</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="bootstrap/bootstrap.min.css" rel="stylesheet" />
<script src="bootstrap/bootstrap.bundle.min.js"></script>

<style>
 #t{
 	font-size: 32pt;
 	color: navy;
 }
</style>
<?php session_start(); ?>
</head>

<body>
<form name  ="frmLogin"
      action="chkLogin.php"
      method="post">
<table border="1" bordercolor="black" cellspacing="0" align="center" width="20%">
<tr>
 <th colspan="2" id="t">Login</th>
</tr>

<tr>
 <td><label for="user">Username</label></td>
 <td><input type        ="text" 
            id          ="user" 
            name        ="user"
            autocomplete="off"
            value       ="<?php if(isset($_SESSION['user'])) echo $_SESSION['user']; ?>" /></td>
</tr>

<tr>
 <td><label for="pass">Password</label></td>
 <td><input type="password" id="pass" name="pass" 
 	        value="<?php if(isset($_SESSION['pass'])) echo $_SESSION['pass']; ?>"/></td>
</tr>

<tr>
 <td colspan="2" align="right">
  <input type="submit" value="Login" class="btn btn-success" />
 </td>
</tr>

<tr>
 <td colspan="2">
  <input type="checkbox" name="keep" /> Keep me logged in
 </td>
</tr>

<tr>
 <td colspan="2">
 	<?php 
 	  if(isset($_SESSION['msg'])) echo $_SESSION['msg'];
         	
        unset($_SESSION['msg']);
        unset($_SESSION['user']);
        unset($_SESSION['pass']);

 	?>
 </td>
</tr>
</table>
</form>
</body>
</html>
