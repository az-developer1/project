<?php
  include 'connection.php';

  $SID = $_GET['SID'];
    
  if(isset($_GET['chkDel'])){
    $del = $_GET['chkDel'];

    foreach($del as $d){
      $sqlDel = "Delete From saleDetail Where SaleID = " . $SID . " And MovieID = " . $d;
      mysqli_query($con, $sqlDel);
    }

  }

  else {
    $MID = $_GET['MID'];

    $sqlDel = "Delete From saleDetail Where SaleID = " . $SID . " And MovieID = " . $MID;

    mysqli_query($con, $sqlDel);
  }


  $rschkContent = mysqli_query($con, "Select * From saleDetail Where SaleID=" . $SID);
  
  $num_rows= mysqli_num_rows($rschkContent);
  
  if ($num_rows > 0){      
     header('location:basketDetail.php');
     die;
  }
  else
     header('location:home.php');
    
?>