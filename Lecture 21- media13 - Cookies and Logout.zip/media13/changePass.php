<!doctype html>
<html>
<head>
<title>Change Password</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="bootstrap/bootstrap.min.css" rel="stylesheet" />
<script src="bootstrap/bootstrap.bundle.min.js"></script>

<style>
 #header{
 	font-size: 24pt;
 	color: navy;
 }
</style>	

<?php 
  session_start(); 
  $client  = $_SESSION['client'];
?>
</head>

<body>
<form name  ="frmChangePass"
      action="chkChangePass.php"
      method="post">

<table border     ="1"
       bordercolor="black"
       cellspacing="0"
       align      ="center"
       width      ="20%">

<caption><?php echo "Current Client: " . $client; ?></caption>

<tr>
 <th colspan="2" id="header">Change Password</th>
</tr>       

<tr>
 <td><label for="oldPass">Old Password</label></td>
 <td><input type ="password" 
 	        id   ="oldPass" 
 	        name ="oldPass"
 	        value="<?php if(isset($_SESSION['oldPass'])) echo $_SESSION['oldPass']; ?>" /></td>
</tr>

<tr>
 <td><label for="newPass">New Password</label></td>
 <td><input type ="password" 
 	        id   ="newPass" 
 	        name ="newPass"
 	        value="<?php if(isset($_SESSION['newPass'])) echo $_SESSION['newPass']; ?>"  /></td>
</tr>

<tr>
 <td><label for="confirm">Confirm</label></td>
 <td><input type ="password" 
 	        id   ="confirm" 
 	        name ="confirm"
 	        value="<?php if(isset($_SESSION['confirm'])) echo $_SESSION['confirm']; ?>"  /></td>
</tr>

<tr>
 <td colspan="2" align="right">
  <input type="submit" value="Change" class="btn btn-success" />
 </td>
</tr>

<tr>
 <td colspan="2">
 	<?php 
 	  if(isset($_SESSION['msg'])) echo $_SESSION['msg']; 
 	    
 	  unset($_SESSION['msg']);
 	  unset($_SESSION['oldPass']);
 	  unset($_SESSION['newPass']);
 	  unset($_SESSION['confirm']);
 	?>
 </td> 	
</tr>
</table>       

</form>
</body>
</html>