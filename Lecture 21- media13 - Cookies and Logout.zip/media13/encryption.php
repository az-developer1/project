<?php
function Encrypt($P){
   $encP='';
   for($i=0; $i<strlen($P); $i++){
      $ch = $P[$i];
      if($ch >= 'A' && $ch <= 'Z')
          $encP = $encP . chr(ord($ch) + 5) . '1';
      else
        if($ch >= 'a' && $ch <= 'z')
          $encP = $encP . chr(ord($ch) - 5) . '2';          
        else
          if($ch >= '0' && $ch <= '9')
              $encP = $encP . chr(ord($ch) + 3) . '3';          
          else
            if($ch == " ")
              $encP = $encP . 's4'; 
            else
              $encP = $encP . chr(ord($ch) - 3) . '5';
    }    
    return $encP;                           
 }


 function Decrypt($P){
   $encP='';
   for($i=0; $i<strlen($P); $i=$i+2){
      $ch = $P[$i];
      $sy = $P[$i+1];

      if($sy == 1)
          $encP = $encP . chr(ord($ch) - 5);
      else
        if($sy == 2)
          $encP = $encP . chr(ord($ch) + 5);          
        else
          if($sy == 3)
              $encP = $encP . chr(ord($ch) - 3);          
          else
            if($sy == 4)
              $encP = $encP . ' '; 
            else
              if($sy == 5)
               $encP = $encP . chr(ord($ch) + 3);
    }    
    return $encP;                           
 }


 function chkPass($P){
  $cCapital = 0;
  $cSmall   = 0;
  $cDigit   = 0;
  $cSymbol  = 0;
  $cSpace   = 0;

  for($i=0; $i<strlen($P); $i++){
     $ch = $P[$i];
     if($ch >= 'A' && $ch <= 'Z')
       $cCapital++;
     else
       if($ch >= 'a' && $ch <= 'z')
          $cSmall++;
       else
         if($ch >= '0' && $ch <= '9')
           $cDigit++;
         else
           if($ch == ' ')
             $cSpace++;
           else
             $cSymbol++;
   }

   if($cCapital== 0 || $cSmall==0 || $cDigit==0 || $cSymbol==0 || $cSpace > 0)
      return false;

   return true;
 }
?>