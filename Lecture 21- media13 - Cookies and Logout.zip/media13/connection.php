<?php
	$server   = 'localhost';
	$user     = 'root';
	$pass     = '';
	$database = 'media';

	$con = new mysqli($server, $user, $pass, $database);

    //Sets the character set to be used when sending data from and to the database server.
    mysqli_set_charset($con, "utf8mb4");
?>