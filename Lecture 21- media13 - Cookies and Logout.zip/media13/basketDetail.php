<!doctype html>
<html>
<head>
<title>Basket Detail</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/bootstrap.min.css">
<link href="styles/style.css" rel="stylesheet" type="text/css" />

<style>
 body{
   font-family: calibri;
   font-size: 12pt;
 }

 a{
   color: rgb(0, 64, 128);
   text-decoration: none;
 }

 a:hover{
   color: red;
 }


 th, td{
  border-top: 1px dotted grey;
  border-bottom: 1px dotted grey;  
 }

 #logo{
   background-image: url(assets/logo.jpg);
   background-repeat: no-repeat; 
   background-size: cover;   
   border: 2px solid black;
   border-radius: 20%;
   height: 100px;
   width: 140px;
 }
</style>

<?php  
  include 'connection.php';
  session_start();
  $client  = $_SESSION['client'];
  $_SESSION['return'] = 'Basket';

  $sqlBasket = "Select clients.ClientID as CID, FName, LName, sales.SaleID as SID, SaleDate, saleDetail.MovieID as MID, Qty, Title, ProduceYear, DirectorName From clients, sales, saleDetail, Movies, Directors Where clients.ClientID = sales.ClientID And sales.SaleID = saleDetail.SaleID And saleDetail.MovieID = movies.MovieID And movies.DirectorID = directors.DirectorID And Opened = 1 And clients.ClientID = " . $client;
  
  $rsBasket = mysqli_query($con, $sqlBasket);

  $rBasket = mysqli_fetch_assoc($rsBasket);
?>

<script>
  function chkAll(){
    var chkAll = document.getElementById("chkAll");
    var del    = document.getElementById("chkDel");
    if(chkAll.checked){
      for(i=0; i<chkDel.length; i++)
        chkDel[i].checked=true;
    }
    else{
      for(i=0; i<chkDel.length; i++)
        chkDel[i].checked=false;
    }
  }
</script>

</head>

<body>
<div class="container-fluid 
            p-3
            bg-danger 
            text-white">

  <div class="row">
    <div class="col-md-12">
      <div id="logo"></div>
    </div>
  </div>
</div>

<table border     ="1"
       bordercolor="blacK"
       cellspacing="0"
       align      ="center"
       width      ="60%" 
       style      ="margin-top:20px;">
<tr>
 <td colspan="3" align="left">Client Name: <?php echo $rBasket['FName'] . ' ' . $rBasket['LName']; ?></td>
 <th>Basket #: <?php echo $rBasket['SID']; ?></th>
 <td colspan="2" align="right">Creation Date: <?php echo $rBasket['SaleDate']; ?></td>
</tr>

<tr>
 <th>&nbsp;</th>
 <th><input type="checkbox" id="chkAll" onchange="chkAll()" /></th>
 <th>Movie Title</th>
 <th>Production Year</th>
 <th>Director Name</th>
 <th>Qty</th> 
</tr>  

<form name="frmBasketDetail">
 <input type="hidden" name="SID" value="<?php echo $rBasket['SID']; ?>" />
<?php 
  // reset the records
  mysqli_data_seek($rsBasket,0);

  $color="#E8F5E2";
  while($rBasket = mysqli_fetch_assoc($rsBasket)){
?>

<tr bgcolor="<?php echo $color; ?>">
  <td align="center" width="4%">
    <a href="delMovie.php?SID=<?php echo $rBasket['SID']; ?>&MID=<?php echo $rBasket['MID']; ?>">
     <img src="assets/trash.png" />
    </a>     
  </td>
  <td width="4%" align="center">
     <input type="checkbox" id="chkDel" name="chkDel[]" value="<?php echo $rBasket['MID']; ?>" />
  </td>
  <td width="40%">
    <a href="moviedetails.php?movid=<?php echo $rBasket['MID']; ?>">
      <?php echo $rBasket['Title']; ?>
    </a>
  </td>
  <td align="center" width="15%"><?php echo $rBasket['ProduceYear']; ?> </td>
  <td width="30%"><?php echo $rBasket['DirectorName']; ?></td>
  <td align="center" width="7%"><?php echo $rBasket['Qty']; ?></td>
</tr>

<?php
   if($color=="white")
     $color="#E8F5E2";
   else
     $color="white";
 }
?>

<tr>
  <td colspan="6" align="right">
    <input type="button" class="btn" value="Delete"   onclick="delMultipleMovies()" />
    <input type="button" class="btn" value="Checkout" onclick="checkout()" />
  </td>
</tr>

</form>
</table>  

<script>
 function delMultipleMovies(){
  document.frmBasketDetail.action="delMovie.php";
  document.frmBasketDetail.submit();
 }

 function checkout(){
   document.frmBasketDetail.action="creditCard.php";
   document.frmBasketDetail.submit();
 }
</script>     
</body>
</html>